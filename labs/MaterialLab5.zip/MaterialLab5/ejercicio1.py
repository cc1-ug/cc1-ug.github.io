import random

def roundNumber(numero, digitos):
	# IMPLEMENTE ESTA SUBRUTINA
	return 0
	# por el momento devolvemos cero para poder probar sin causar error


# ********* NO MODIFIQUE ESTE CODIGO *********************

def testing(testsv):
	count = 1
	right = 0
	while count <= len(testsv) :
		print('Ejecutando Test#',count,":")
		n = testsv[count - 1][0]
		print('NUMERO ORIGINAL:', n)
		c = testsv[count - 1][1]
		print('CIFRAS:',c)
		result = roundNumber(n,c)
		print('NUMERO TRUNCADO:', result)
		result = roundNumber(n,c)
		if result == testsv[count - 1][2]:
			print('RESULTADO ES: correcto :)')
			right += 1
		else:
			print('RESULTADO ES: incorrecto :)')
		print('-----------------------------')
		count += 1
	return right

# ********* NO MODIFIQUE ESTE CODIGO *********************

def autoevaluacion():
	print('\nMODO AUTOEVALUACION\n----------------------')
	correctas = 0

	tests = [[768.128907, 3, 768.128], [345.1898211, 1, 345.1], [9502.898123789, 6, 9502.898123]]
	tests = tests + [[768.128907, 2, 768.12], [8.9134008, 4, 8.9134], [345.1898211, 5, 345.18982]]
	tests = tests + [[95.898123789, 0, 95], [1453.1010101078, 7, 1453.1010101]]
	tests = tests + [[19302.898123789, 8, 19302.89812378], [2853.1010101078, 9, 2853.101010107]]

	print(tests)

	correct = testing(tests)
	print('-----------------------------\nRESULTADOS GENERALES:')
	print(correct,'de',len(tests),'respuestas correctas')
	nota = round(100 * (correct / len(tests)),0)
	print('Usted sacaria',nota,'% en este ejercicio (aprox)')

# ************** NO MODIFIQUE EL CODIGO SIGUIENTE ***************

def aleatorio():
	print('\nMODO ALEATORIO\n----------------------')
	x = 2
	while x < 7:
		aleatorio = (random.randint(0,90000000) + 10000000) / pow(10,x+2)
		r = aleatorio
		print('aleatorio:',aleatorio)
		print('El numero', r, 'debe quedar con', x, 'decimales')
		print('Su funcion dio como resultado:',roundNumber(r, x))
		x += 1

def menu():
	print(' CC1 - 2020 - Lab#5 - Ejercicio1')
	print('---------------------------------')
	opcion = 0
	while(opcion != 3) :
		print('\nOpciones de testing:')
		print('(1) Modo autoevaluacion\n(2) Modo aleatorio\n(3) Salir del programa\n')
		try:
			opcion = int(input("Ingrese su opcion: "))
			if opcion == 1:
				autoevaluacion()
			elif opcion == 2:
				aleatorio()
			elif opcion == 3:
				print("Saliendo del programa ...")
			else:
				print("ERROR: Opcion invalida! Solo hay opciones 1, 2 o 3\n")
		except ValueError:
			print("ERROR: Opcion invalida! No ingreso un numero entero\n")
			opcion = 0

menu()
