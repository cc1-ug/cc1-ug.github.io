import turtle
import time

# NO MODIFIQUE ESTE CODIGO
turtle.setup(200,420)
window = turtle.Screen()
window.title('Semaforo')
window.bgcolor('black')

yturtle = turtle.Turtle()
rturtle = turtle.Turtle()
gturtle = turtle.Turtle()
# *************************

# IMPLEMENTE SU FUNCION AQUI
# Recuerde declararla como se le haya indicado







# ********************************************

# ********** NO MODIFIQUE NINGUN CODIGO DESPUES DE ESTO *********
def dibujar_circulo(trt,color, posx, posy):
    trt.penup()
    trt.setposition(posx,posy)
    trt.pendown()
    trt.color(color,color)
    trt.dot(100)

def cambiarColor(siguienteColor):
    global yturtle
    global rturtle
    global gturtle
    global window

    if siguienteColor == "RED" :
        dibujar_circulo(yturtle, "darkgrey", 0, 0)
        dibujar_circulo(rturtle, "red", 0, 120)
        dibujar_circulo(gturtle, "darkgrey", 0, -120)
        time.sleep(1)
    elif siguienteColor == "YELLOW" :
        dibujar_circulo(yturtle, "yellow", 0, 0)
        dibujar_circulo(rturtle, "darkgrey", 0, 120)
        dibujar_circulo(gturtle, "darkgrey", 0, -120)
        time.sleep(1)
    elif siguienteColor == "GREEN" :
        dibujar_circulo(yturtle, "darkgrey", 0, 0)
        dibujar_circulo(rturtle, "darkgrey", 0, 120)
        dibujar_circulo(gturtle, "green", 0, -120)
        time.sleep(1)
    elif siguienteColor == "GRAY" :
        dibujar_circulo(yturtle, "darkgrey", 0, 0)
        dibujar_circulo(rturtle, "darkgrey", 0, 120)
        dibujar_circulo(gturtle, "darkgrey", 0, -120)
        time.sleep(1)
    else:
        dibujar_circulo(yturtle, "darkgrey", 0, 0)
        dibujar_circulo(rturtle, "darkgrey", 0, 120)
        dibujar_circulo(gturtle, "darkgrey", 0, -120)
        time.sleep(1)

def main():
    color_actual = "YELLOW"
    for change in range(10):
        color_sig = siguienteColor(color_actual)
        print(color_actual,"->",color_sig)
        cambiarColor(color_sig)
        color_actual = color_sig

print(' CC1 - 2020 - Lab#5 - Ejercicio2')
print('---------------------------------')
print('Dibujando Semaforo ...')
dibujar_circulo(yturtle, "darkgrey", 0, 0)
dibujar_circulo(rturtle, "darkgrey", 0, 120)
dibujar_circulo(gturtle, "darkgrey", 0, -120)
print('Iniciando cambio de colores ...')
main()
